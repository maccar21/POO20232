public class MiClase {
    public static void main(String[] args) {
        int numero1 = 90;
        int numero2 = 100;

        int resultado = numero1 + numero2;

        System.out.println(resultado);
    }
}
